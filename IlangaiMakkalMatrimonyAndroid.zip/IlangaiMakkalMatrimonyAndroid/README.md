# Ilangai Makkal Matrimony — Basic Android App

This is a basic Android Studio project that loads https://ilangaimakkalmatrimony.com/ inside an Android WebView.

## Included
- Website inside the app
- JavaScript and DOM storage enabled for modern website login/forms
- Android back button navigates website history
- Loading progress bar
- Friendly retry screen for main-page network errors
- Phone and email links handed to the appropriate Android app

## Build an APK
1. Install Android Studio.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `IlangaiMakkalMatrimonyAndroid` folder.
4. Let Gradle sync. Use JDK 17 if prompted.
5. Connect an Android phone or use an emulator, then click **Run**.
6. To create an installable APK, choose **Build > Build APK(s)**.

The project uses Android Gradle Plugin 8.7.3, compile SDK 35, and minimum Android 6.0 (API 23).

## Important
This is a website-wrapper starter project, not a native redesign. Website functionality depends on the website itself and its compatibility with Android WebView. Test login, registration, payments, file uploads, and any OTP flow on a real device before publishing. If you publish to Google Play, add the required privacy policy, app icon, store listing, and comply with current Play policies.
